
public interface Metodos {
	public void Guardar(Perro perro);
	public void Editar(Perro perro);
	public void Eliminar(Perro perro);
	public Perro Buscar(Perro perro);
	public void mostrar();
}
