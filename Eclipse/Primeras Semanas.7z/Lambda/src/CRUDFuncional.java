@FunctionalInterface
public interface CRUDFuncional {
	public abstract Perro crud(Perro perro);
}
