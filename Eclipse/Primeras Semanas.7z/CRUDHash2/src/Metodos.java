
public interface Metodos {
	public void agregar(Object clave, Object obj);
	public void editar(Object clave, Object obj);
	public void eliminar(Object clave);
	public Object buscar(Object clave);
	public void mostrar();
}
