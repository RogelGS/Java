

class Principal {
   public static void main(String[] args) {
	    Parent p = new Parent();
	    DerivedOne d1 = new DerivedOne();
	    DerivedTwo d2 = new DerivedTwo();
	    
	    d1 = d2;
   }
 }
