
public class DerivedOne extends Parent{

}
