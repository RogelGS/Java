
public class DerivedTwo extends Parent{

}
