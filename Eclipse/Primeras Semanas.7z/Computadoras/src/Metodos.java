
public interface Metodos {
	public void agregar(Object obj);
	public void editar(Object obj);
	public void eliminar(Object obj);
	public Object buscar(Object obj);
	public void mostrar();
}
