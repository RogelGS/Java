
public class ImplementacionProfesor extends CRUD{

}
