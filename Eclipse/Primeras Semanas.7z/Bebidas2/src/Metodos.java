
public interface Metodos {
	public void editar(int indice, Bebida bebida);
	public void agregar(Bebida bebida);
	public void eliminar(int indice);
	
	public Bebida buscar(int indice);
	public void mostrar();
}
