
public interface Metodos {
	public void guardar(Object object);
	public void editar(Object object);
	public void eliminar(Object object);
	public Object buscar(Object object);
	public void mostrar();
}
