
public class Perro {
	String nombre = "Scooby do";
	static String raza = "Gran Danes";
	static final String genero = "Macho";
	
	final int edad = 3;
	
	public void ladrar() {
		System.out.println("El perro ladra");
	}
	
	public static void correr() {
		System.out.println("El perro esta corriendo");
	}
}
