
public interface Metodos {
	public void guardar(Mueble mueble);
	public void editar(Mueble mueble);
	public void eliminar(Mueble mueble);
	public Mueble buscar(Mueble mueble);
	public void mostrar();
}
