public class Test1{
    
    public static void main(String[] args){
    	String a=null; String b=null;
    	if( a == b| b.equals(a)){
    	System.out.println("iguales");

    	}

    }

}