
public interface Metodos {
	public void guardar(Object objeto);
	public void editar(Object objeto);
	public void eliminar(Object objeto);
	public Object buscar(Object objeto);
	public void mostrar();
}
