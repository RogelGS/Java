@FunctionalInterface
public interface CRUD {
	public abstract Object crud(Object clave, Object obj);
}
