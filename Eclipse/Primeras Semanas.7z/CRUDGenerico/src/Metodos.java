
public interface Metodos {
	public void agregar(Object obj);
	public void editar(int index, Object obj);
	public void eliminar(int index);
	public Object buscar(int clave);
	public void mostrar();
}
