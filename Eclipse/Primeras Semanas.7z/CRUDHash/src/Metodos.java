
public interface Metodos {
	public void agregar(int clave, Object obj);
	public void editar(int clave, Object obj);
	public void eliminar(int clave);
	public Object buscar(int clave);
	public void mostrar();
}
