package com.mx.genral;

public interface Metodos {

	public void guardar(Object obj);

	public void editar(Object obj);

	public void eliminar(Object obj);

	public Object buscar(Object obj);

	public void mostrar();

}
