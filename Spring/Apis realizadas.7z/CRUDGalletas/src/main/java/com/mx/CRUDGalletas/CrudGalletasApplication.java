package com.mx.CRUDGalletas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudGalletasApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudGalletasApplication.class, args);
	}

}
