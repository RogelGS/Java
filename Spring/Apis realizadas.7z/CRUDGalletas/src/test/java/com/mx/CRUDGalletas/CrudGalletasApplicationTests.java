package com.mx.CRUDGalletas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudGalletasApplicationTests {

	@Test
	void contextLoads() {
	}

}
