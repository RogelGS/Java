package com.mx.CRUDTenni;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudTenniApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudTenniApplication.class, args);
	}

}
