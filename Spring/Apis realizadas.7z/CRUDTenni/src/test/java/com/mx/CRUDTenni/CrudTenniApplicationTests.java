package com.mx.CRUDTenni;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudTenniApplicationTests {

	@Test
	void contextLoads() {
	}

}
