package com.mx.CRUDGym;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudGymApplicationTests {

	@Test
	void contextLoads() {
	}

}
