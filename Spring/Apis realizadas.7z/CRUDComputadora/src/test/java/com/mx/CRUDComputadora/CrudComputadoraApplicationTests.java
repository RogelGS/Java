package com.mx.CRUDComputadora;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudComputadoraApplicationTests {

	@Test
	void contextLoads() {
	}

}
