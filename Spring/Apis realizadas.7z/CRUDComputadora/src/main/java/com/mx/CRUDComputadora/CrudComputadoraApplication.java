package com.mx.CRUDComputadora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudComputadoraApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudComputadoraApplication.class, args);
	}

}
