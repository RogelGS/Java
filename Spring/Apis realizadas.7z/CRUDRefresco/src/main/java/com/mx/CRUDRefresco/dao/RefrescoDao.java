package com.mx.CRUDRefresco.dao;

import org.springframework.data.repository.CrudRepository;

import com.mx.CRUDRefresco.entity.Refresco;

public interface RefrescoDao extends CrudRepository<Refresco, Integer>{

}
