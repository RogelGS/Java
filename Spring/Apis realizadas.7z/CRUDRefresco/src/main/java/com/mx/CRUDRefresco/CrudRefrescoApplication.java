package com.mx.CRUDRefresco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudRefrescoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudRefrescoApplication.class, args);
	}

}
