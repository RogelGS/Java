package com.mx.CRUDRefresco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudRefrescoApplicationTests {

	@Test
	void contextLoads() {
	}

}
