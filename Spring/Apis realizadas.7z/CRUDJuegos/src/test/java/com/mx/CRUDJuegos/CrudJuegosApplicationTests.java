package com.mx.CRUDJuegos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudJuegosApplicationTests {

	@Test
	void contextLoads() {
	}

}
