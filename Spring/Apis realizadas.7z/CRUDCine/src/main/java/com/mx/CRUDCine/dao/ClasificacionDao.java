package com.mx.CRUDCine.dao;

import org.springframework.data.repository.CrudRepository;

import com.mx.CRUDCine.dominio.Clasificacion;

public interface ClasificacionDao extends CrudRepository<Clasificacion, Integer>{

}
