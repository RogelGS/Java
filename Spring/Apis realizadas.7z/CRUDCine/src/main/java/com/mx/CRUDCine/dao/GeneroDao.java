package com.mx.CRUDCine.dao;

import org.springframework.data.repository.CrudRepository;

import com.mx.CRUDCine.dominio.Genero;

public interface GeneroDao extends CrudRepository<Genero, Integer>{

}
