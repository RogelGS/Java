package com.mx.CRUDCine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudCineApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudCineApplication.class, args);
	}

}
