package com.mx.CRUDSeries;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudSeriesApplicationTests {

	@Test
	void contextLoads() {
	}

}
