package com.mx.CRUDSeries;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudSeriesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudSeriesApplication.class, args);
	}

}
