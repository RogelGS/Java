package com.mx.CRUDAuto.dao;

import org.springframework.data.repository.CrudRepository;

import com.mx.CRUDAuto.entidad.Auto;

public interface AutoDao extends CrudRepository<Auto, Integer>{

}
