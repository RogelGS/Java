package com.mx.CRUDPelicula;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudPeliculaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudPeliculaApplication.class, args);
	}

}
