package com.mx.CRUDVegetales;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudVegetalesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudVegetalesApplication.class, args);
	}

}
