package com.mx.CRUDVegetales;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudVegetalesApplicationTests {

	@Test
	void contextLoads() {
	}

}
