package com.mx.CRUDPadreHijo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudPadreHijoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudPadreHijoApplication.class, args);
	}

}
