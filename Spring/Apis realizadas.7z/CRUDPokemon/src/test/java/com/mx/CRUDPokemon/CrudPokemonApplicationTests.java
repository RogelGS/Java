package com.mx.CRUDPokemon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudPokemonApplicationTests {

	@Test
	void contextLoads() {
	}

}
