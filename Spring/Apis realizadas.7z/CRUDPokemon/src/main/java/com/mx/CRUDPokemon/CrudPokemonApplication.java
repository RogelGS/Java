package com.mx.CRUDPokemon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudPokemonApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudPokemonApplication.class, args);
	}

}
