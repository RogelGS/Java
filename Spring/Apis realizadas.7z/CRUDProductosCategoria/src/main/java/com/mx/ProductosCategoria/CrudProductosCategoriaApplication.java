package com.mx.ProductosCategoria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudProductosCategoriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudProductosCategoriaApplication.class, args);
	}

}
