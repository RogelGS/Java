package com.mx.ProductosCategoria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudProductosCategoriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
