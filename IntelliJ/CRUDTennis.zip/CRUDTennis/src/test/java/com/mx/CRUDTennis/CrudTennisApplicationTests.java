package com.mx.CRUDTennis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudTennisApplicationTests {

	@Test
	void contextLoads() {
	}

}
