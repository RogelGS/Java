package com.mx.CRUDTennis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudTennisApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudTennisApplication.class, args);
	}

}
