package com.mx.mailtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MailTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
